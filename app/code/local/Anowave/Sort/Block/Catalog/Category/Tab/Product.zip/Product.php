<?php
class Anowave_Sort_Block_Catalog_Category_Tab_Product extends Mage_Adminhtml_Block_Catalog_Category_Tab_Product
{
	public function __construct()
    {
        parent::__construct();
        
        $this->setDefaultSort('position');
        $this->setDefaultDir('ASC');
    }
    
    protected function _prepareCollection()
    {
    	if ($this->getCategory()->getId()) {
    		$this->setDefaultFilter(array('in_category'=>1));
    	}
    	$collection = Mage::getModel('catalog/product')->getCollection()
    	->addAttributeToSelect('name')
    	->addAttributeToSelect('sku')
    	->addAttributeToSelect('price')
    	->addStoreFilter($this->getRequest()->getParam('store'))
    	->joinField('position','catalog/category_product','position','product_id=entity_id','category_id='.(int) $this->getRequest()->getParam('id', 0),'left')
    	->joinField('qty','cataloginventory/stock_item','qty','product_id=entity_id','{{table}}.stock_id=1','left');
    	
    	$this->setCollection($collection);
    
    	if ($this->getCategory()->getProductsReadonly()) {
    		$productIds = $this->_getSelectedProducts();
    		if (empty($productIds)) {
    			$productIds = 0;
    		}
    		$this->getCollection()->addFieldToFilter('entity_id', array('in'=>$productIds));
    	}
    }
    
	protected function _prepareColumns()
	{
		parent::_prepareColumns();
		
		$this->addColumn('qty', array(
			'header'    => Mage::helper('sales')->__('Stock Level'),
			'width'     => '20',
			'type'      => 'number',
			'index'     => 'qty'
		));
		
		$this->addColumn('arrange', array
		(
			'header'    => Mage::helper('catalog')->__('Sort'),
			'width'     => '20px',
			'type'      => 'text',
			'align'		=> 'center',
			'index'     => 'arrange',
			'renderer'  => 'sort/drag'
        ));
	}

	protected function _preparePage()
    {	
    	if (!Mage::helper('sort')->isLimitApplied())
    	{
    		$this->getCollection()->setCurPage(1);
			$this->getCollection()->setPageSize(false);
    	}
    	else return parent::_preparePage();
    }
	
	public function getRowUrl()
	{
		return null;
	}
}